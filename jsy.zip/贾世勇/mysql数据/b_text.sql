/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_text
-- ----------------------------
DROP TABLE IF EXISTS `b_text`;
CREATE TABLE `b_text` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_digset` text NOT NULL COMMENT '文章择要',
  `b_text` longtext NOT NULL COMMENT '文章正文',
  `b_createtime` datetime NOT NULL COMMENT '文章发布时间',
  `b_field` varchar(80) DEFAULT NULL COMMENT '审核失败的原因',
  `b_title` varchar(100) DEFAULT NULL COMMENT '文章标题',
  `b_sta` tinyint(1) DEFAULT '0' COMMENT '审核状态0（待审核）1（审核通过）2（审核不通过）',
  `b_author` varchar(40) DEFAULT NULL COMMENT '文章作者',
  `b_public` tinyint(1) DEFAULT NULL COMMENT '是否公开1（所有人可见） 0（仅自己可见）',
  `b_con` tinyint(1) unsigned zerofill DEFAULT '0' COMMENT '评论量',
  `b_colnum` int(11) unsigned zerofill DEFAULT NULL COMMENT '收藏的数量',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `b_pv` int(11) DEFAULT '0' COMMENT '浏览量',
  `b_zannum` int(11) DEFAULT '0' COMMENT '支持的数量',
  `b_fannums` int(11) DEFAULT '0' COMMENT '反对的数量',
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='博文文章表';

-- ----------------------------
-- Records of b_text
-- ----------------------------
INSERT INTO `b_text` VALUES ('1', '发的方法付付付', '发的发的方法付付付付付付付付付付付付付付付发发发', '2019-10-19 15:13:59', null, '放得开的反馈给看看反馈不规范', '1', null, '1', '1', '00000000002', '24', '281', '0', '0');
INSERT INTO `b_text` VALUES ('2', '毒贩夫妇付次饭饭', '发的方法付付付', '2019-10-19 15:14:51', null, '毒贩夫妇的付付付付', '1', '李四啊', '1', '0', '00000000000', '34', '114', '0', '0');
INSERT INTO `b_text` VALUES ('3', '的方法地方', '毒贩夫妇付多', '2019-10-19 15:15:34', null, '的点点滴滴', '1', '李四啊', '1', '0', '00000000000', '34', '785', '0', '0');
INSERT INTO `b_text` VALUES ('4', '毒贩夫妇付', '毒贩夫妇 ', '2019-10-20 23:04:52', null, '反反复复', '1', '李四啊', '1', '0', '00000000001', '34', '6', '1', '0');
INSERT INTO `b_text` VALUES ('5', '所得到的', '申达股份多看看 ', '2019-10-20 23:08:48', null, '所得到的', '1', '李四啊', '1', '0', '00000000000', '34', '3', '2', '0');
INSERT INTO `b_text` VALUES ('6', '毒贩夫妇付付付付付付付付付付付付', '反反复复付付付付付付付付付付付付付付付付', '2019-10-20 23:44:02', null, '点点滴滴', '1', '李四啊', '1', '0', '00000000001', '34', '6', '0', '0');
INSERT INTO `b_text` VALUES ('7', '柔柔弱弱若若若若若若若若若若若', '人孔盖数据发送价格加不加', '2019-10-20 23:46:41', null, '二人人人若若', '1', '李四啊', '1', '0', '00000000001', '34', '38', '0', '0');
INSERT INTO `b_text` VALUES ('8', '微微儿二二二二二二二二不r', '热鹅鹅鹅鹅鹅鹅鹅鹅鹅鹅鹅鹅饿鹅鹅鹅饿', '2019-10-20 23:47:54', null, '呃呃呃呃呃', '1', '李四啊', '1', '0', '00000000001', '34', '171', '1', '0');
INSERT INTO `b_text` VALUES ('9', '测试demo', '您好 我是贾世勇', '2019-10-22 10:46:50', null, '测试', '0', '李四啊', '0', '0', null, '34', '0', '0', '0');
