/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_content
-- ----------------------------
DROP TABLE IF EXISTS `b_content`;
CREATE TABLE `b_content` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_uid` tinyint(11) DEFAULT NULL COMMENT '用户id',
  `b_ptime` datetime DEFAULT NULL COMMENT '评论的时间',
  `b_stas` tinyint(1) DEFAULT '0' COMMENT '评论的状态0(待审核)1（审核通过）2（审核不通过）',
  `b_content` text COMMENT '评论内容',
  `b_names` varchar(50) DEFAULT NULL COMMENT '用户',
  `b_artid` int(11) DEFAULT NULL COMMENT '文章id',
  `b_img` varchar(200) DEFAULT NULL COMMENT '用户图片',
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='评论表';

-- ----------------------------
-- Records of b_content
-- ----------------------------
INSERT INTO `b_content` VALUES ('3', '24', '2019-10-19 17:59:15', '1', '树的深度多多多多', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('4', '24', '2019-10-19 17:59:19', '0', '树的深度多多多多所得到的多多多多多多多多多多多多多', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('5', '24', '2019-10-19 17:59:30', '0', '额人而让人', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('6', '24', '2019-10-19 17:59:38', '0', '所得到的多多多多多多多', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('7', '24', '2019-10-19 18:00:08', '0', '三生三世', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('8', '24', '2019-10-19 18:00:12', '0', '三生三世是是是', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('9', '24', '2019-10-19 18:01:38', '0', '三生三世', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('10', '24', '2019-10-19 18:01:42', '0', '点点滴滴', '李三', '3', 'http://www.blog.com/upload/3_glowingbeaches_hawaii.jpg');
INSERT INTO `b_content` VALUES ('19', '34', '2019-10-21 19:18:51', '1', '疯疯癫癫付付付付付', '李四啊', '1', 'http://www.blog.com/upload/5db2b0b082dce385f784232cbb56b2e8.jpg');
