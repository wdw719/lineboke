/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_name
-- ----------------------------
DROP TABLE IF EXISTS `b_name`;
CREATE TABLE `b_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增 ',
  `b_email` varchar(40) NOT NULL COMMENT 'QQ邮箱',
  `b_phone` char(11) NOT NULL COMMENT '手机号',
  `b_logname` varchar(30) DEFAULT NULL COMMENT '登录名称',
  `b_showname` varchar(30) DEFAULT NULL COMMENT '显示名称',
  `b_password` varchar(32) DEFAULT NULL COMMENT '密码',
  `b_sel` tinyint(1) DEFAULT '0' COMMENT '查询状态0(查询) 1(不查询or封号)',
  `b_snum` tinyint(1) DEFAULT '0' COMMENT '是否封号禁用0（未禁言）1（已禁言） 2（封号）',
  `b_distime` datetime DEFAULT NULL COMMENT '封号的时间',
  `b_pic` varchar(200) DEFAULT NULL COMMENT '用户图片',
  `b_att` int(11) DEFAULT '0' COMMENT '关注数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `邮箱账号` (`b_email`),
  UNIQUE KEY `b_logname` (`b_logname`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of b_name
-- ----------------------------
INSERT INTO `b_name` VALUES ('1', '1948639123942@qq.com', '18031078570', '奥菲1', '爱妃', '12345', '0', '2', '2019-10-16 10:28:42', null, null);
INSERT INTO `b_name` VALUES ('2', '19481233@qq.com', '18031078570', '奥菲13', '点点滴滴', '12355', '0', '2', '2019-10-16 10:44:47', null, null);
INSERT INTO `b_name` VALUES ('3', '1948123@qq.com', '18031078570', '奥菲55', '点点滴是是是', '12355', '0', '1', '2019-10-16 15:41:53', null, null);
INSERT INTO `b_name` VALUES ('4', '194812333@qq.com', '18031078570', '发动机盖家33', '方法放得开', '435656', '0', '0', '2019-10-14 13:25:40', null, null);
INSERT INTO `b_name` VALUES ('7', '4830038025@qq.com', '13111111111', '多对多对对', '神神道道对对', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('6', '483003805@qq.com', '13111111111', '多对多', '神神道道', '1234AAbb', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('8', '4838025@qq.com', '13111111111', '电视剧积分', '电饭锅股份', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('9', '483805@qq.com', '13111111111', '电视剧是对的', '电饭电放费', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('10', '48330038025@qq.com', '13111111111', '电视电放费', '当韩寒', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('11', '480025@qq.com', '13111111111', '电电话回访放费', '当韩寒东方饭店', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('12', '480022346643465@qq.com', '13111111111', '电电话回访红烧带鱼放费', '个功夫格斗', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('13', '48063344423365@qq.com', '13111111111', '电电话回收到货发烧带鱼放费', '个功夫格斗的分解发电机房', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('14', '56663003805@qq.com', '13111111111', '的合法化', '地方柔肤水', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('15', '555453805@qq.com', '13111111111', '是冬季度假酒店', '地方柔肤水是冬季获得的', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('16', '44830038025@qq.com', '13111111111', '和合法化方法', '东方华府换行符', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('17', '1233553458025@qq.com', '13111111111', '颂德歌功', '打电话的', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('18', '122483003805@qq.com', '13111111111', '函数的好', '所得到的', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('21', '2344554556@qq.com', '13111111111', '发广告', '李三啊', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, 'http://www.blog.com/upload/5abd6a3871bbb95e1621e86204792de9.jpg', null);
INSERT INTO `b_name` VALUES ('24', '48302333805@qq.com', '13111111111', '拉阿拉', '李三一', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, 'http://www.blog.com/upload/261b08b2bf4a5855b3335f3af01d1cd1.jpg', '34');
INSERT INTO `b_name` VALUES ('34', '1948639942@qq.com', '13111111111', '张三啊', '李四啊', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, 'http://www.blog.com/upload/5db2b0b082dce385f784232cbb56b2e8.jpg', '2');
INSERT INTO `b_name` VALUES ('35', '1814769940@qq.com', '13111111111', '柳州博', '刘洲伯', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
INSERT INTO `b_name` VALUES ('36', '1948942@qq.com', '13111111111', '贾世勇', '柳州博', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, 'http://www.blog.com/upload/LaDigue_EN-CA1115245085_1920x1080.jpg', null);
INSERT INTO `b_name` VALUES ('37', '1948639111942@qq.com', '13111111111', '邮箱是', '嘟嘟嘟', '83445ab2fb6f7c8961e64d40ad577e9a', '0', '0', null, null, null);
