/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:49:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_attention
-- ----------------------------
DROP TABLE IF EXISTS `b_attention`;
CREATE TABLE `b_attention` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `userid` int(11) DEFAULT NULL COMMENT '用户登录id',
  `dataid` int(11) DEFAULT NULL COMMENT '发表文章的用户id',
  `g_time` datetime DEFAULT NULL COMMENT '关注的时间',
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='关注与文章的关联表';

-- ----------------------------
-- Records of b_attention
-- ----------------------------
INSERT INTO `b_attention` VALUES ('40', '24', '34', '2019-10-22 11:05:06');
INSERT INTO `b_attention` VALUES ('39', '34', '24', '2019-10-22 11:04:42');
