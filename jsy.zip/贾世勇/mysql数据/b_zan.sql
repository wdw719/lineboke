/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_zan
-- ----------------------------
DROP TABLE IF EXISTS `b_zan`;
CREATE TABLE `b_zan` (
  `z_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `wen_id` int(11) DEFAULT NULL COMMENT '文章id',
  `zan_sta` tinyint(1) DEFAULT NULL COMMENT '状态(1)支持 （2）不支持',
  PRIMARY KEY (`z_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='点赞的关联用户id和文章的id\r\n';

-- ----------------------------
-- Records of b_zan
-- ----------------------------
INSERT INTO `b_zan` VALUES ('8', '34', '1', '2');
INSERT INTO `b_zan` VALUES ('7', '24', '3', '1');
INSERT INTO `b_zan` VALUES ('6', '34', '3', '1');
INSERT INTO `b_zan` VALUES ('9', '24', '1', '2');
INSERT INTO `b_zan` VALUES ('10', '24', '8', '1');
INSERT INTO `b_zan` VALUES ('11', '24', '6', '2');
INSERT INTO `b_zan` VALUES ('12', '24', '4', '1');
INSERT INTO `b_zan` VALUES ('13', '24', '5', '1');
INSERT INTO `b_zan` VALUES ('14', '24', '5', '1');
