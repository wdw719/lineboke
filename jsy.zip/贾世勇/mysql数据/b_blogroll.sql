/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:49:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_blogroll
-- ----------------------------
DROP TABLE IF EXISTS `b_blogroll`;
CREATE TABLE `b_blogroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_bltit` varchar(50) DEFAULT NULL COMMENT '友情链接标题',
  `b_blink` varchar(255) DEFAULT NULL COMMENT '友情链接',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='友情链接表';

-- ----------------------------
-- Records of b_blogroll
-- ----------------------------
INSERT INTO `b_blogroll` VALUES ('2', '三生三世', 'wwww.baicddsf.com');
