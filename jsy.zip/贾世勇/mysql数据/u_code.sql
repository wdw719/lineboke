/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:51:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for u_code
-- ----------------------------
DROP TABLE IF EXISTS `u_code`;
CREATE TABLE `u_code` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(32) DEFAULT NULL COMMENT '用户注册的code码',
  `b_times` datetime DEFAULT NULL COMMENT '用户注册的时间',
  `b_dtime` datetime DEFAULT NULL COMMENT '用户过了这段时间重新登录',
  `uids` int(11) DEFAULT NULL COMMENT '用户id',
  `b_sta` tinyint(1) DEFAULT '0' COMMENT '状态（0）未激活（1）激活',
  `b_code` char(32) DEFAULT NULL COMMENT '过期的code',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='用户code';

-- ----------------------------
-- Records of u_code
-- ----------------------------
INSERT INTO `u_code` VALUES ('1', '5f2771b6f9f8b5a438466c4452587cd5', '2019-10-15 20:36:13', '2019-10-15 22:36:13', '18', '1', null);
INSERT INTO `u_code` VALUES ('2', 'bce7353b946b419663758599c8cc4c8d', '2019-10-15 20:46:25', '2019-10-15 22:46:25', '19', '1', null);
INSERT INTO `u_code` VALUES ('3', '5c5179353338ea6ad66e871778db2e9b', '2019-10-15 20:53:30', '2019-10-15 22:53:30', '22', '1', null);
INSERT INTO `u_code` VALUES ('4', '5c5179353338ea6ad66e871778db2e9b', '2019-10-15 21:14:56', '2020-04-16 23:14:56', '24', '1', null);
INSERT INTO `u_code` VALUES ('5', null, '2019-10-16 08:59:15', '2019-10-16 10:59:15', '25', '1', null);
INSERT INTO `u_code` VALUES ('6', null, '2019-10-16 10:26:07', '2019-10-16 12:26:07', '26', '1', null);
INSERT INTO `u_code` VALUES ('7', null, '2019-10-16 10:31:01', '2019-10-16 12:31:01', '27', '1', null);
INSERT INTO `u_code` VALUES ('8', 'f07ef4b572b137901a4eae796cdd71e1', '2019-10-16 10:33:05', '2019-10-16 15:06:06', '28', '1', null);
INSERT INTO `u_code` VALUES ('9', '8f5a5b9134c3c80f3743a3f3f7b81d13', '2019-10-16 12:12:17', '2019-10-16 14:12:17', '29', '1', null);
INSERT INTO `u_code` VALUES ('10', '25e80c72aa3dfa09eac39ab0e3c4c5a2', '2019-10-16 12:15:54', '2019-10-25 15:25:45', '30', '1', null);
INSERT INTO `u_code` VALUES ('11', '4d7e749e5506869ad543a8ddfc0efb40', '2019-10-16 18:49:54', '2019-10-16 20:49:54', '31', '1', null);
INSERT INTO `u_code` VALUES ('13', '90a0eefda4fe844924b29e7f8230a2e9', '2019-10-19 10:45:43', '2019-10-19 12:45:43', '33', '1', null);
INSERT INTO `u_code` VALUES ('14', 'd60e4bf68378c2f9eb1ef57cb5725afb', '2019-10-19 10:52:03', '2019-10-21 17:23:01', '34', '1', null);
INSERT INTO `u_code` VALUES ('15', '45502aadcfbfd79e221abc200064b387', '2019-10-21 14:26:55', '2019-10-21 16:26:55', '35', '1', null);
INSERT INTO `u_code` VALUES ('16', 'aba1fa3d7474547497106cefb954896a', '2019-10-21 14:30:50', '2019-10-21 16:30:50', '36', '1', null);
INSERT INTO `u_code` VALUES ('17', '16a4fc3265764eb55d2fef4b2ea620b1', '2019-10-21 14:34:54', '2019-10-21 16:34:54', '37', '1', null);
