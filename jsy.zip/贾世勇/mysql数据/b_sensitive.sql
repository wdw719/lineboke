/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_sensitive
-- ----------------------------
DROP TABLE IF EXISTS `b_sensitive`;
CREATE TABLE `b_sensitive` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `sen_word` varchar(150) DEFAULT NULL COMMENT '敏感词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='敏感词库';

-- ----------------------------
-- Records of b_sensitive
-- ----------------------------
INSERT INTO `b_sensitive` VALUES ('1', '习近平');
INSERT INTO `b_sensitive` VALUES ('2', '毛泽东');
INSERT INTO `b_sensitive` VALUES ('3', '傻叉');
INSERT INTO `b_sensitive` VALUES ('4', '法轮功');
INSERT INTO `b_sensitive` VALUES ('5', '蛤');
INSERT INTO `b_sensitive` VALUES ('6', '傻逼');
INSERT INTO `b_sensitive` VALUES ('7', '小姐');
