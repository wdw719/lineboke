/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_work
-- ----------------------------
DROP TABLE IF EXISTS `b_work`;
CREATE TABLE `b_work` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `work` varchar(20) DEFAULT NULL COMMENT '职位',
  `section` varchar(30) DEFAULT NULL COMMENT '部门',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_work
-- ----------------------------
INSERT INTO `b_work` VALUES ('1', 'CEO', '技术部');
INSERT INTO `b_work` VALUES ('2', '项目经理', '技术部经理');
INSERT INTO `b_work` VALUES ('3', '组长', '技术部组长');
INSERT INTO `b_work` VALUES ('4', '员工', '技术部员工');
