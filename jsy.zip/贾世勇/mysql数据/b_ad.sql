/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:49:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_ad
-- ----------------------------
DROP TABLE IF EXISTS `b_ad`;
CREATE TABLE `b_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_adlink` varchar(255) DEFAULT NULL COMMENT '广告链接',
  `b_img` varchar(200) DEFAULT NULL COMMENT '广告图片',
  `b_title` varchar(50) DEFAULT NULL COMMENT '广告标题',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='广告表';

-- ----------------------------
-- Records of b_ad
-- ----------------------------
INSERT INTO `b_ad` VALUES ('1', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('4', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('5', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('6', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('7', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('8', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('9', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
INSERT INTO `b_ad` VALUES ('10', 'www.liyang.com', 'http://www.blog.com/upload/6CC07AC0_8622_4770_88A6_F77D47B8707A.jpg', '李阳');
