/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_user
-- ----------------------------
DROP TABLE IF EXISTS `b_user`;
CREATE TABLE `b_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `b_password` char(32) NOT NULL DEFAULT '' COMMENT '用户密码',
  `b_time` datetime NOT NULL COMMENT '注册时间',
  `pid` tinyint(1) unsigned zerofill NOT NULL COMMENT '0 boss 1 ceo 2 组长 3 员工 ',
  `alert_name` varchar(20) NOT NULL COMMENT '显示名',
  `phone` char(11) NOT NULL COMMENT '手机号',
  `sel_sta` varchar(10) DEFAULT NULL COMMENT '查询职业的状态1(项目经理、组长、员工)',
  `work` varchar(50) DEFAULT NULL COMMENT 'boos（超级管理员）ceo(管理员)',
  `section` varchar(50) DEFAULT NULL COMMENT '部门',
  PRIMARY KEY (`id`),
  UNIQUE KEY `用户名` (`b_username`) USING HASH
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='后台管理用户表';

-- ----------------------------
-- Records of b_user
-- ----------------------------
INSERT INTO `b_user` VALUES ('1', '1948639942@qq.com', '140a485f445b4c857925120355cc7a96', '2019-10-12 18:33:54', '0', '老大一', '15089004895', '', 'BOSS', '乐享博客');
INSERT INTO `b_user` VALUES ('28', '123422156@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-11 21:11:41', '3', '王五一', '13303100653', '', '组长', '技术部组长');
INSERT INTO `b_user` VALUES ('26', '19486399422@qq.com', '140a485f445b4c857925120355cc7a96', '2019-10-11 21:03:19', '2', '多对多1', '13303100653', '', '项目经理', '技术部经理');
INSERT INTO `b_user` VALUES ('31', '1948622399421@qq.com', '140a485f445b4c857925120355cc7a96', '2019-10-12 16:55:54', '1', '都好得很', '13303100653', '', 'CEO', '技术部');
INSERT INTO `b_user` VALUES ('32', '19486223991421@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:39:13', '2', '都好得很', '13303100653', '', '项目经理', '技术部经理');
INSERT INTO `b_user` VALUES ('36', '191148639942@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:47:28', '1', '对对的', '13303100653', '', 'CEO', '技术部');
INSERT INTO `b_user` VALUES ('35', '1924212286399422@qq.com', '64b6cc8c661d0d805bce9028874c4d7f', '2019-10-12 14:46:33', '3', '都好得很', '13303100653', '', '员工', '技术部员工');
INSERT INTO `b_user` VALUES ('37', '19221148639942@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:48:26', '1', '对对对是', '13303120653', '', '项目经理', '技术部经理');
INSERT INTO `b_user` VALUES ('38', '1948639911@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:50:01', '3', '都好得很', '13303100653', '', '组长', '技术部组长');
INSERT INTO `b_user` VALUES ('39', '11948639911@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:50:28', '4', '都好得很', '13303100653', '', '员工', '技术部员工');
INSERT INTO `b_user` VALUES ('42', '123486399422@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a', '2019-10-12 14:58:57', '2', '多对多', '13303100653', null, '项目经理', '技术部经理');
INSERT INTO `b_user` VALUES ('43', '133422156@qq.com', '140a485f445b4c857925120355cc7a96', '2019-10-12 15:00:17', '2', '都好得很', '13303100653', '1', '项目经理', '技术部经理');
INSERT INTO `b_user` VALUES ('44', '133424156@qq.com', '140a485f445b4c857925120355cc7a96', '2019-10-12 15:00:43', '3', '都好得很', '13303100653', '1', '组长', '技术部组长');
