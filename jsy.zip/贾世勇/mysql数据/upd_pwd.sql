/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:51:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for upd_pwd
-- ----------------------------
DROP TABLE IF EXISTS `upd_pwd`;
CREATE TABLE `upd_pwd` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `upd_user` varchar(30) NOT NULL COMMENT '账号 ',
  `upd_password` char(32) NOT NULL COMMENT '修改的密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of upd_pwd
-- ----------------------------
INSERT INTO `upd_pwd` VALUES ('1', '1948639942@qq.com', '123456AAbb');
INSERT INTO `upd_pwd` VALUES ('2', '1948639942@qq.com', '140a485f445b4c857925120355cc7a96');
INSERT INTO `upd_pwd` VALUES ('3', '1948639942@qq.com', '83445ab2fb6f7c8961e64d40ad577e9a');
