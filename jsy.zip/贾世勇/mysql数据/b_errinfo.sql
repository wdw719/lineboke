/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_errinfo
-- ----------------------------
DROP TABLE IF EXISTS `b_errinfo`;
CREATE TABLE `b_errinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `b_errorinfo` varchar(80) DEFAULT NULL COMMENT '审核失败原因',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='审核失败原因表';

-- ----------------------------
-- Records of b_errinfo
-- ----------------------------
INSERT INTO `b_errinfo` VALUES ('1', '内容太水');
INSERT INTO `b_errinfo` VALUES ('2', '涉黄涉毒');
INSERT INTO `b_errinfo` VALUES ('3', '政治敏感');
INSERT INTO `b_errinfo` VALUES ('4', '广告');
