/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : boke

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-10-22 13:50:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_collect
-- ----------------------------
DROP TABLE IF EXISTS `b_collect`;
CREATE TABLE `b_collect` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `bid` int(11) DEFAULT NULL COMMENT '文章id',
  `coll_sta` tinyint(1) DEFAULT '0' COMMENT '收藏的状态值（0）未收藏（1）已收藏',
  PRIMARY KEY (`co_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='收藏表';

-- ----------------------------
-- Records of b_collect
-- ----------------------------
INSERT INTO `b_collect` VALUES ('9', '24', '1', '1');
INSERT INTO `b_collect` VALUES ('2', '24', '3', '1');
INSERT INTO `b_collect` VALUES ('8', '24', '4', '1');
INSERT INTO `b_collect` VALUES ('7', '24', '6', '1');
INSERT INTO `b_collect` VALUES ('6', '24', '8', '1');
INSERT INTO `b_collect` VALUES ('10', '24', '7', '1');
INSERT INTO `b_collect` VALUES ('11', '34', '1', '1');
